package com.training;

public class sequence {
	public static void main(String[] args) {
		String first = args[0], second = args[1];
		System.out.println("The numbers are "+first+" "+second);
		
		int i = 1, n = 13, firstTerm, secondTerm;
		firstTerm= Integer.parseInt(first);
		secondTerm= Integer.parseInt(second);
		
	    System.out.println("Fibonacci Series till " + n + " terms:");

	    while (i <= n) {
	      System.out.print(firstTerm + ", ");

	      int nextTerm = firstTerm + secondTerm;
	      firstTerm = secondTerm;
	      secondTerm = nextTerm;

	      i++;
	    }

	}

}
