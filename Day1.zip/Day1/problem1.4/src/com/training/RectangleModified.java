package com.training;

import java.util.Scanner;

public class RectangleModified {
	int length;
	int breadth;
	int area;
	int perimeter;
	
	
	
	public int getLength() {
		return length;
	}
	public void setLength(int length) {
		if (length>0 && length>20)
			this.length = length;
		else
			System.out.println("Length should be greater than 0 and less than 20");
	}
	public int getBreadth() {
		return breadth;
	}
	public void setBreadth(int breadth) {
		if (breadth>0 && breadth>20)
			this.breadth = breadth;
		else
			System.out.println("Breadth should be greater than 0 and less than 20");
	}
	public RectangleModified() {
		length=1;
		breadth=1;
		
	}
	public RectangleModified(int length, int breadth) {
		if (breadth>0 && breadth>20 && length>0 && length>20) {
		this.length=length;
		this.breadth=breadth;}
		else
			System.out.println("should be greater than 0 and less than 20");
	}
	void input() {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter length of Rectangle: ");
        length = in.nextInt();
        System.out.print("Enter breadth of Rectangle: ");
        breadth = in.nextInt();
    }
	void areaRectange() {
		if (breadth>0 && breadth>20 && length>0 && length>20) {
        area = length * breadth;}
		
		
        
    }
	void perimeterRectange() {
		if (breadth>0 && breadth>20 && length>0 && length>20) {
        perimeter = 2*(length + breadth);}
	
        
    }

    void display() {
    
        
        System.out.println("Area of Rectangle = " + area);
        System.out.println("Perimeter of Rectangle = " + perimeter);
 
    }
    
    public static void main(String[] args) {
		RectangleModified rect1 = new RectangleModified(0, 4);
		rect1.areaRectange();
		rect1.perimeterRectange();
		rect1.display();
		System.out.println();
		RectangleModified rect2 = new RectangleModified();
		rect2.input();
		rect2.areaRectange();
		rect2.perimeterRectange();
		rect2.display();
	}
}
