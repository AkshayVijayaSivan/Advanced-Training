package com.training;

public abstract class instrument {
	public abstract void play();

}
