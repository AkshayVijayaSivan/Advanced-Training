package com.training;

public class Guitar extends instrument {
	@Override
	public void play() {
		System.out.println("Guitar is playing  tin  tin  tin for Guitar class");

	}


}
