package com.training;

public class Syrup implements MedicineInfo {

	@Override
	public void displayLabel() {
		System.out.println("For Internal use only");

	}

}
