package com.training;

public class Tablet implements MedicineInfo {

	@Override
	public void displayLabel() {
		System.out.println("Store in cold dry places only");

	}

}
