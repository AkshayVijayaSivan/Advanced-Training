package com.training;

public interface MedicineInfo {
	public void displayLabel();

}
