package com.training;

import java.util.Scanner;

public class Rectangle {
	int length;
	int breadth;
	int area;
	
	public Rectangle() {
		length=0;
		breadth=0;
		
	}
	public Rectangle(int length, int breadth) {
		this.length=length;
		this.breadth=breadth;
	}
	void input() {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter length of rectangle: ");
        length = in.nextInt();
        System.out.print("Enter breadth of rectangle: ");
        breadth = in.nextInt();
    }
	void calculate() {
        area = length * breadth;
        
    }

    void display() {
        System.out.println("Area of Rectangle = " + area);
       
    }
    
    public static void main(String[] args) {
		Rectangle rect1 = new Rectangle(5, 4);
		rect1.calculate();
		rect1.display();
		System.out.println();
		Rectangle rect2 = new Rectangle();
		rect2.input();
		rect2.calculate();
		rect2.display();
	}



}
