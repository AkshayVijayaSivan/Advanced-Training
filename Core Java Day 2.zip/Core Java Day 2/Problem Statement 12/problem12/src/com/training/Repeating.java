package com.training;

public class Repeating {
	public static void main(String[] args) {
		int[]arr={ 1, 2, 3, 10, 6, 4, 3, 7, 10 };
		repeat(arr);
		
	}
	public static void repeat(int[] arr) {
		int length = arr.length;
		boolean flag=false;
		for(int i=0;i<length;i++) {
			for(int j=i+1;j<length;j++) {
				
				if(arr[i]==arr[j]) {
					System.out.println("the first repeating number is "+arr[i]);
					flag=true;
					break;
				}
			}
			if (flag==true) {
				break;}
		}
	}

}
